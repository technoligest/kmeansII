/*
 * This class is created so that if another class needs all iteration runners, they would only
 * include this class and it would automatically incldue all necessary other classes.
 *
 * Created by Yaser Alkayale on 2017-06-19.
 *
 */

#ifndef KMEANSII_ITERATIONRUNNERS_H
#define KMEANSII_ITERATIONRUNNERS_H

#include "lloyd_iteration_runner.h"
#include "globals.h"

#endif //KMEANSII_ITERATIONRUNNERS_H
