//
// Created by Yaser Alkayale on 2018-01-24.
//

#ifndef KMEANSII_GLOBALS_H
#define KMEANSII_GLOBALS_H

//The globals that we will need to include in EVERY file.
//Things that might not be needed in some files should NOT be here.

//#define DEBUG_KMEANS

#endif //KMEANSII_GLOBALS_H
